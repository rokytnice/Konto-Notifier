package org.rochlitz.hbci.base;

public class BasisApp {
	
	public static String fileanme = "comdirect_passport_ar__1.dat";

}
