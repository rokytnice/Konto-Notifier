package org.kapott.hbci.passport;

class A 
{
    final public int GetResult(int a, int b) { return 0; } 
    
    public int aMethod()
    {
          int i = 0;
        i++;
        return i;
    }
} 
 